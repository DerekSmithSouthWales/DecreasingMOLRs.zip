The clique partitions for a t-subgraph (t=15, k-1=56) are contained in the file:
 
14Clique_partitions_k-1=56_branch_leaf.txt

The corresponding set of 14 decreasing mutually orthogonal Latin rectangles are contained in the file:

14_decreasing_Latin-rectangles_k-1=56.txt